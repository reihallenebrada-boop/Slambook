package com.example.slambookproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;

public class AddEntryActivity extends AppCompatActivity {

    private EditText etFullName;
    private EditText etNickname;
    private EditText etBirthday;
    private EditText etFavoriteColor;
    private EditText etFavoriteFood;
    private EditText etHobby;
    private EditText etDream;
    private EditText etFavoriteQuote;

    private ImageView ivEntryImage;

    private Button btnChooseImage;
    private Button btnSaveEntry;

    private DatabaseHelper databaseHelper;

    private String selectedImagePath = "";

    private File cameraFile;
    private Uri cameraUri;

    // Camera result
    private final ActivityResultLauncher<Uri> cameraLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.TakePicture(),
                    success -> {

                        if (
                                success &&
                                        cameraFile != null
                        ) {

                            selectedImagePath =
                                    cameraFile.getAbsolutePath();

                            displayImage(
                                    selectedImagePath
                            );

                        } else {

                            if (cameraFile != null) {

                                ImageUtils.deleteImage(
                                        cameraFile.getAbsolutePath()
                                );
                            }
                        }
                    }
            );

    // Gallery result
    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    uri -> {

                        if (uri != null) {

                            String copiedPath =
                                    ImageUtils
                                            .copyUriToInternalStorage(
                                                    this,
                                                    uri
                                            );

                            if (copiedPath != null) {

                                if (
                                        !selectedImagePath.isEmpty()
                                ) {

                                    ImageUtils.deleteImage(
                                            selectedImagePath
                                    );
                                }

                                selectedImagePath =
                                        copiedPath;

                                displayImage(
                                        selectedImagePath
                                );

                            } else {

                                showDialog(
                                        "Image Error",
                                        "The image could not be selected."
                                );
                            }
                        }
                    }
            );

    // Camera permission
    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {

                        if (granted) {

                            openCamera();

                        } else {

                            showDialog(
                                    "Camera Permission",
                                    "Camera permission is required to take a profile picture."
                            );
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_add_entry
        );

        initializeViews();

        databaseHelper =
                new DatabaseHelper(this);

        btnChooseImage.setOnClickListener(
                v -> showImageSourceDialog()
        );

        btnSaveEntry.setOnClickListener(
                v -> saveEntry()
        );
    }

    private void initializeViews() {

        etFullName =
                findViewById(R.id.etFullName);

        etNickname =
                findViewById(R.id.etNickname);

        etBirthday =
                findViewById(R.id.etBirthday);

        etFavoriteColor =
                findViewById(R.id.etFavoriteColor);

        etFavoriteFood =
                findViewById(R.id.etFavoriteFood);

        etHobby =
                findViewById(R.id.etHobby);

        etDream =
                findViewById(R.id.etDream);

        etFavoriteQuote =
                findViewById(R.id.etFavoriteQuote);

        ivEntryImage =
                findViewById(R.id.ivEntryImage);

        btnChooseImage =
                findViewById(R.id.btnChooseImage);

        btnSaveEntry =
                findViewById(R.id.btnSaveEntry);
    }

    private void showImageSourceDialog() {

        String[] choices = {
                "Camera",
                "Gallery"
        };

        new AlertDialog.Builder(this)
                .setTitle("Add Profile Picture")
                .setItems(
                        choices,
                        (dialog, which) -> {

                            if (which == 0) {

                                checkCameraPermission();

                            } else {

                                openGallery();
                            }
                        }
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    private void checkCameraPermission() {

        if (
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
        ) {

            openCamera();

        } else {

            cameraPermissionLauncher.launch(
                    Manifest.permission.CAMERA
            );
        }
    }

    private void openCamera() {

        try {

            cameraFile =
                    ImageUtils.createImageFile(this);

            cameraUri =
                    FileProvider.getUriForFile(
                            this,
                            getPackageName() +
                                    ".fileprovider",
                            cameraFile
                    );

            cameraLauncher.launch(
                    cameraUri
            );

        } catch (Exception e) {

            showDialog(
                    "Camera Error",
                    "The camera could not be opened."
            );
        }
    }

    private void openGallery() {

        galleryLauncher.launch(
                "image/*"
        );
    }

    private void displayImage(
            String imagePath
    ) {

        android.graphics.Bitmap bitmap =
                ImageUtils.loadImage(
                        imagePath
                );

        if (bitmap != null) {

            ivEntryImage.setImageBitmap(
                    bitmap
            );
        }
    }

    // Validate required fields
    private boolean validateInput() {

        boolean valid = true;

        String fullName =
                etFullName
                        .getText()
                        .toString()
                        .trim();

        String nickname =
                etNickname
                        .getText()
                        .toString()
                        .trim();

        String birthday =
                etBirthday
                        .getText()
                        .toString()
                        .trim();

        if (fullName.isEmpty()) {

            etFullName.setError(
                    "Full name is required"
            );

            etFullName.requestFocus();

            valid = false;
        }

        if (nickname.isEmpty()) {

            etNickname.setError(
                    "Nickname is required"
            );

            if (valid) {
                etNickname.requestFocus();
            }

            valid = false;
        }

        if (birthday.isEmpty()) {

            etBirthday.setError(
                    "Birthday is required"
            );

            if (valid) {
                etBirthday.requestFocus();
            }

            valid = false;
        }

        return valid;
    }

    private void saveEntry() {

        if (!validateInput()) {

            showDialog(
                    "Incomplete Slambook",
                    "Please fill in all required fields."
            );

            return;
        }

        String fullName =
                etFullName
                        .getText()
                        .toString()
                        .trim();

        String nickname =
                etNickname
                        .getText()
                        .toString()
                        .trim();

        String birthday =
                etBirthday
                        .getText()
                        .toString()
                        .trim();

        String favoriteColor =
                etFavoriteColor
                        .getText()
                        .toString()
                        .trim();

        String favoriteFood =
                etFavoriteFood
                        .getText()
                        .toString()
                        .trim();

        String hobby =
                etHobby
                        .getText()
                        .toString()
                        .trim();

        String dream =
                etDream
                        .getText()
                        .toString()
                        .trim();

        String favoriteQuote =
                etFavoriteQuote
                        .getText()
                        .toString()
                        .trim();

        long id =
                databaseHelper.addEntry(
                        fullName,
                        nickname,
                        birthday,
                        favoriteColor,
                        favoriteFood,
                        hobby,
                        dream,
                        favoriteQuote,
                        selectedImagePath
                );

        if (id != -1) {

            new AlertDialog.Builder(this)
                    .setTitle("Saved!")
                    .setMessage(
                            "The slambook entry was saved successfully."
                    )
                    .setPositiveButton(
                            "View",
                            (dialog, which) -> {

                                Intent intent =
                                        new Intent(
                                                this,
                                                ViewEntryActivity.class
                                        );

                                intent.putExtra(
                                        "ENTRY_ID",
                                        (int) id
                                );

                                startActivity(intent);

                                finish();
                            }
                    )
                    .setNegativeButton(
                            "Close",
                            (dialog, which) ->
                                    finish()
                    )
                    .show();

        } else {

            showDialog(
                    "Save Failed",
                    "The slambook entry could not be saved."
            );
        }
    }

    private void showDialog(
            String title,
            String message
    ) {

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(
                        "OK",
                        null
                )
                .show();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}