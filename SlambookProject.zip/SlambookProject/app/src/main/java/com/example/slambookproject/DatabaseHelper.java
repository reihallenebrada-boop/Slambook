package com.example.slambookproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "slambook.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_ENTRIES = "slambook_entries";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_FULL_NAME = "full_name";
    public static final String COLUMN_NICKNAME = "nickname";
    public static final String COLUMN_BIRTHDAY = "birthday";
    public static final String COLUMN_FAVORITE_COLOR = "favorite_color";
    public static final String COLUMN_FAVORITE_FOOD = "favorite_food";
    public static final String COLUMN_HOBBY = "hobby";
    public static final String COLUMN_DREAM = "dream";
    public static final String COLUMN_FAVORITE_QUOTE = "favorite_quote";
    public static final String COLUMN_IMAGE_PATH = "image_path";

    public DatabaseHelper(Context context) {
        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createTable =
                "CREATE TABLE " + TABLE_ENTRIES + " (" +

                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        COLUMN_FULL_NAME + " TEXT NOT NULL, " +

                        COLUMN_NICKNAME + " TEXT NOT NULL, " +

                        COLUMN_BIRTHDAY + " TEXT NOT NULL, " +

                        COLUMN_FAVORITE_COLOR + " TEXT, " +

                        COLUMN_FAVORITE_FOOD + " TEXT, " +

                        COLUMN_HOBBY + " TEXT, " +

                        COLUMN_DREAM + " TEXT, " +

                        COLUMN_FAVORITE_QUOTE + " TEXT, " +

                        COLUMN_IMAGE_PATH + " TEXT" +

                        ")";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {

        db.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_ENTRIES
        );

        onCreate(db);
    }

    // Add new slambook entry
    public long addEntry(
            String fullName,
            String nickname,
            String birthday,
            String favoriteColor,
            String favoriteFood,
            String hobby,
            String dream,
            String favoriteQuote,
            String imagePath
    ) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                COLUMN_FULL_NAME,
                fullName
        );

        values.put(
                COLUMN_NICKNAME,
                nickname
        );

        values.put(
                COLUMN_BIRTHDAY,
                birthday
        );

        values.put(
                COLUMN_FAVORITE_COLOR,
                favoriteColor
        );

        values.put(
                COLUMN_FAVORITE_FOOD,
                favoriteFood
        );

        values.put(
                COLUMN_HOBBY,
                hobby
        );

        values.put(
                COLUMN_DREAM,
                dream
        );

        values.put(
                COLUMN_FAVORITE_QUOTE,
                favoriteQuote
        );

        values.put(
                COLUMN_IMAGE_PATH,
                imagePath
        );

        long id =
                db.insert(
                        TABLE_ENTRIES,
                        null,
                        values
                );

        db.close();

        return id;
    }

    // Get one slambook entry
    public Entry getEntry(int id) {

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor =
                db.query(
                        TABLE_ENTRIES,
                        null,
                        COLUMN_ID + " = ?",
                        new String[]{
                                String.valueOf(id)
                        },
                        null,
                        null,
                        null
                );

        Entry entry = null;

        if (cursor != null &&
                cursor.moveToFirst()) {

            String fullName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_FULL_NAME
                            )
                    );

            String nickname =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_NICKNAME
                            )
                    );

            String birthday =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_BIRTHDAY
                            )
                    );

            String favoriteColor =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_FAVORITE_COLOR
                            )
                    );

            String favoriteFood =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_FAVORITE_FOOD
                            )
                    );

            String hobby =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_HOBBY
                            )
                    );

            String dream =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_DREAM
                            )
                    );

            String favoriteQuote =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_FAVORITE_QUOTE
                            )
                    );

            String imagePath =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COLUMN_IMAGE_PATH
                            )
                    );

            entry =
                    new Entry(
                            id,
                            fullName,
                            nickname,
                            birthday,
                            favoriteColor,
                            favoriteFood,
                            hobby,
                            dream,
                            favoriteQuote,
                            imagePath
                    );

            cursor.close();
        }

        db.close();

        return entry;
    }

    // Update slambook entry
    public boolean updateEntry(
            int id,
            String fullName,
            String nickname,
            String birthday,
            String favoriteColor,
            String favoriteFood,
            String hobby,
            String dream,
            String favoriteQuote,
            String imagePath
    ) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                COLUMN_FULL_NAME,
                fullName
        );

        values.put(
                COLUMN_NICKNAME,
                nickname
        );

        values.put(
                COLUMN_BIRTHDAY,
                birthday
        );

        values.put(
                COLUMN_FAVORITE_COLOR,
                favoriteColor
        );

        values.put(
                COLUMN_FAVORITE_FOOD,
                favoriteFood
        );

        values.put(
                COLUMN_HOBBY,
                hobby
        );

        values.put(
                COLUMN_DREAM,
                dream
        );

        values.put(
                COLUMN_FAVORITE_QUOTE,
                favoriteQuote
        );

        values.put(
                COLUMN_IMAGE_PATH,
                imagePath
        );

        int rowsUpdated =
                db.update(
                        TABLE_ENTRIES,
                        values,
                        COLUMN_ID + " = ?",
                        new String[]{
                                String.valueOf(id)
                        }
                );

        db.close();

        return rowsUpdated > 0;
    }

    // Delete slambook entry
    public boolean deleteEntry(int id) {

        SQLiteDatabase db =
                getWritableDatabase();

        int rowsDeleted =
                db.delete(
                        TABLE_ENTRIES,
                        COLUMN_ID + " = ?",
                        new String[]{
                                String.valueOf(id)
                        }
                );

        db.close();

        return rowsDeleted > 0;
    }
}
