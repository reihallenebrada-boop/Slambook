package com.example.slambookproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ViewEntryActivity extends AppCompatActivity {

    private ImageView ivViewImage;

    private TextView tvViewFullName;
    private TextView tvViewNickname;
    private TextView tvViewBirthday;
    private TextView tvViewFavoriteColor;
    private TextView tvViewFavoriteFood;
    private TextView tvViewHobby;
    private TextView tvViewDream;
    private TextView tvViewFavoriteQuote;

    private Button btnEditEntry;
    private Button btnDeleteEntry;

    private DatabaseHelper databaseHelper;

    private int entryId;

    private Entry currentEntry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_view_entry
        );

        initializeViews();

        databaseHelper =
                new DatabaseHelper(this);

        entryId =
                getIntent()
                        .getIntExtra(
                                "ENTRY_ID",
                                -1
                        );

        if (entryId == -1) {

            showErrorAndFinish(
                    "The slambook entry could not be found."
            );

            return;
        }

        btnEditEntry.setOnClickListener(
                v -> openEditScreen()
        );

        btnDeleteEntry.setOnClickListener(
                v -> showDeleteDialog()
        );

        loadEntry();
    }

    private void initializeViews() {

        ivViewImage =
                findViewById(R.id.ivViewImage);

        tvViewFullName =
                findViewById(R.id.tvViewFullName);

        tvViewNickname =
                findViewById(R.id.tvViewNickname);

        tvViewBirthday =
                findViewById(R.id.tvViewBirthday);

        tvViewFavoriteColor =
                findViewById(R.id.tvViewFavoriteColor);

        tvViewFavoriteFood =
                findViewById(R.id.tvViewFavoriteFood);

        tvViewHobby =
                findViewById(R.id.tvViewHobby);

        tvViewDream =
                findViewById(R.id.tvViewDream);

        tvViewFavoriteQuote =
                findViewById(R.id.tvViewFavoriteQuote);

        btnEditEntry =
                findViewById(R.id.btnEditEntry);

        btnDeleteEntry =
                findViewById(R.id.btnDeleteEntry);
    }

    private void loadEntry() {

        currentEntry =
                databaseHelper.getEntry(
                        entryId
                );

        if (currentEntry == null) {

            showErrorAndFinish(
                    "This slambook entry no longer exists."
            );

            return;
        }

        tvViewFullName.setText(
                currentEntry.getFullName()
        );

        tvViewNickname.setText(
                "Nickname: " +
                        currentEntry.getNickname()
        );

        tvViewBirthday.setText(
                "Birthday: " +
                        getValueOrDefault(
                                currentEntry.getBirthday()
                        )
        );

        tvViewFavoriteColor.setText(
                "Favorite Color: " +
                        getValueOrDefault(
                                currentEntry.getFavoriteColor()
                        )
        );

        tvViewFavoriteFood.setText(
                "Favorite Food: " +
                        getValueOrDefault(
                                currentEntry.getFavoriteFood()
                        )
        );

        tvViewHobby.setText(
                "Hobby: " +
                        getValueOrDefault(
                                currentEntry.getHobby()
                        )
        );

        tvViewDream.setText(
                "Dream: " +
                        getValueOrDefault(
                                currentEntry.getDream()
                        )
        );

        tvViewFavoriteQuote.setText(
                "Favorite Quote: \"" +
                        getValueOrDefault(
                                currentEntry.getFavoriteQuote()
                        ) +
                        "\""
        );

        displayImage(
                currentEntry.getImagePath()
        );
    }

    private String getValueOrDefault(
            String value
    ) {

        if (
                value == null ||
                        value.trim().isEmpty()
        ) {

            return "Not provided";
        }

        return value;
    }

    private void displayImage(
            String imagePath
    ) {

        if (
                imagePath != null &&
                        !imagePath.isEmpty()
        ) {

            android.graphics.Bitmap bitmap =
                    ImageUtils.loadImage(
                            imagePath
                    );

            if (bitmap != null) {

                ivViewImage.setImageBitmap(
                        bitmap
                );

                return;
            }
        }

        ivViewImage.setImageResource(
                android.R.drawable.ic_menu_camera
        );
    }

    private void openEditScreen() {

        Intent intent =
                new Intent(
                        this,
                        EditEntryActivity.class
                );

        intent.putExtra(
                "ENTRY_ID",
                entryId
        );

        startActivity(intent);
    }

    private void showDeleteDialog() {

        new AlertDialog.Builder(this)

                .setTitle("Delete Slambook Entry")

                .setMessage(
                        "Are you sure you want to delete " +
                                currentEntry.getNickname() +
                                "'s entry?"
                )

                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                deleteEntry()
                )

                .setNegativeButton(
                        "Cancel",
                        null
                )

                .show();
    }

    private void deleteEntry() {

        boolean deleted =
                databaseHelper.deleteEntry(
                        entryId
                );

        if (deleted) {

            if (
                    currentEntry != null
            ) {

                ImageUtils.deleteImage(
                        currentEntry.getImagePath()
                );
            }

            new AlertDialog.Builder(this)

                    .setTitle("Deleted")

                    .setMessage(
                            "The slambook entry was deleted successfully."
                    )

                    .setPositiveButton(
                            "OK",
                            (dialog, which) ->
                                    finish()
                    )

                    .show();

        } else {

            showDialog(
                    "Delete Failed",
                    "The slambook entry could not be deleted."
            );
        }
    }

    private void showDialog(
            String title,
            String message
    ) {

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(
                        "OK",
                        null
                )
                .show();
    }

    private void showErrorAndFinish(
            String message
    ) {

        new AlertDialog.Builder(this)

                .setTitle("Error")

                .setMessage(message)

                .setPositiveButton(
                        "OK",
                        (dialog, which) ->
                                finish()
                )

                .show();
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (
                databaseHelper != null &&
                        entryId != -1
        ) {

            loadEntry();
        }
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}