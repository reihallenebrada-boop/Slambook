package com.example.slambookproject;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Automatically open the Slambook Add Entry screen
        Intent intent = new Intent(
                MainActivity.this,
                AddEntryActivity.class
        );

        startActivity(intent);

        // Close MainActivity so pressing Back does not
        // return to the Hello World screen.
        finish();
    }
}