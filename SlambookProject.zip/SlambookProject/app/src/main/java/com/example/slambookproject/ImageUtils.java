package com.example.slambookproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ImageUtils {

    private static File getImageDirectory(
            Context context
    ) {

        File directory =
                new File(
                        context.getFilesDir(),
                        "slambook_images"
                );

        if (!directory.exists()) {
            directory.mkdirs();
        }

        return directory;
    }

    // Create a file for a camera photo
    public static File createImageFile(
            Context context
    ) {

        File directory =
                getImageDirectory(context);

        String timeStamp =
                new SimpleDateFormat(
                        "yyyyMMdd_HHmmss",
                        Locale.getDefault()
                ).format(new Date());

        return new File(
                directory,
                "SLAMBOOK_" + timeStamp + ".jpg"
        );
    }

    // Copy a gallery image into app storage
    public static String copyUriToInternalStorage(
            Context context,
            Uri uri
    ) {

        File directory =
                getImageDirectory(context);

        String timeStamp =
                new SimpleDateFormat(
                        "yyyyMMdd_HHmmss",
                        Locale.getDefault()
                ).format(new Date());

        File destination =
                new File(
                        directory,
                        "GALLERY_" + timeStamp + ".jpg"
                );

        try {

            InputStream inputStream =
                    context.getContentResolver()
                            .openInputStream(uri);

            if (inputStream == null) {
                return null;
            }

            FileOutputStream outputStream =
                    new FileOutputStream(destination);

            byte[] buffer =
                    new byte[4096];

            int bytesRead;

            while (
                    (bytesRead =
                            inputStream.read(buffer)) != -1
            ) {

                outputStream.write(
                        buffer,
                        0,
                        bytesRead
                );
            }

            outputStream.flush();

            outputStream.close();
            inputStream.close();

            return destination.getAbsolutePath();

        } catch (Exception e) {

            e.printStackTrace();

            return null;
        }
    }

    public static Bitmap loadImage(
            String imagePath
    ) {

        if (
                imagePath == null ||
                        imagePath.isEmpty()
        ) {
            return null;
        }

        File imageFile =
                new File(imagePath);

        if (!imageFile.exists()) {
            return null;
        }

        return BitmapFactory.decodeFile(
                imageFile.getAbsolutePath()
        );
    }

    public static void deleteImage(
            String imagePath
    ) {

        if (
                imagePath == null ||
                        imagePath.isEmpty()
        ) {
            return;
        }

        File imageFile =
                new File(imagePath);

        if (imageFile.exists()) {
            imageFile.delete();
        }
    }
}