package com.example.slambookproject;

public class Entry {

    private int id;

    private String fullName;
    private String nickname;
    private String birthday;
    private String favoriteColor;
    private String favoriteFood;
    private String hobby;
    private String dream;
    private String favoriteQuote;
    private String imagePath;

    public Entry() {
    }

    public Entry(
            int id,
            String fullName,
            String nickname,
            String birthday,
            String favoriteColor,
            String favoriteFood,
            String hobby,
            String dream,
            String favoriteQuote,
            String imagePath
    ) {
        this.id = id;
        this.fullName = fullName;
        this.nickname = nickname;
        this.birthday = birthday;
        this.favoriteColor = favoriteColor;
        this.favoriteFood = favoriteFood;
        this.hobby = hobby;
        this.dream = dream;
        this.favoriteQuote = favoriteQuote;
        this.imagePath = imagePath;
    }

    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getNickname() {
        return nickname;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getFavoriteColor() {
        return favoriteColor;
    }

    public String getFavoriteFood() {
        return favoriteFood;
    }

    public String getHobby() {
        return hobby;
    }

    public String getDream() {
        return dream;
    }

    public String getFavoriteQuote() {
        return favoriteQuote;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setFavoriteColor(String favoriteColor) {
        this.favoriteColor = favoriteColor;
    }

    public void setFavoriteFood(String favoriteFood) {
        this.favoriteFood = favoriteFood;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public void setDream(String dream) {
        this.dream = dream;
    }

    public void setFavoriteQuote(String favoriteQuote) {
        this.favoriteQuote = favoriteQuote;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
