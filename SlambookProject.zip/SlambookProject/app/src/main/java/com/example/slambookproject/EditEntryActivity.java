package com.example.slambookproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;

public class EditEntryActivity extends AppCompatActivity {

    private EditText etEditFullName;
    private EditText etEditNickname;
    private EditText etEditBirthday;
    private EditText etEditFavoriteColor;
    private EditText etEditFavoriteFood;
    private EditText etEditHobby;
    private EditText etEditDream;
    private EditText etEditFavoriteQuote;

    private ImageView ivEditImage;

    private Button btnReplaceImage;
    private Button btnUpdateEntry;

    private DatabaseHelper databaseHelper;

    private int entryId;

    private Entry currentEntry;

    private String originalImagePath = "";
    private String selectedImagePath = "";

    private File cameraFile;
    private Uri cameraUri;

    // Camera
    private final ActivityResultLauncher<Uri> cameraLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.TakePicture(),
                    success -> {

                        if (
                                success &&
                                        cameraFile != null
                        ) {

                            replaceImage(
                                    cameraFile.getAbsolutePath()
                            );

                        } else {

                            if (cameraFile != null) {

                                ImageUtils.deleteImage(
                                        cameraFile.getAbsolutePath()
                                );
                            }
                        }
                    }
            );

    // Gallery
    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    uri -> {

                        if (uri != null) {

                            String newImagePath =
                                    ImageUtils
                                            .copyUriToInternalStorage(
                                                    this,
                                                    uri
                                            );

                            if (
                                    newImagePath != null
                            ) {

                                replaceImage(
                                        newImagePath
                                );

                            } else {

                                showDialog(
                                        "Image Error",
                                        "The selected image could not be loaded."
                                );
                            }
                        }
                    }
            );

    // Camera permission
    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {

                        if (granted) {

                            openCamera();

                        } else {

                            showDialog(
                                    "Camera Permission",
                                    "Camera permission is required to replace the profile picture."
                            );
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_edit_entry
        );

        initializeViews();

        databaseHelper =
                new DatabaseHelper(this);

        entryId =
                getIntent()
                        .getIntExtra(
                                "ENTRY_ID",
                                -1
                        );

        if (entryId == -1) {

            showErrorAndFinish(
                    "The slambook entry could not be found."
            );

            return;
        }

        loadEntry();

        btnReplaceImage.setOnClickListener(
                v -> showImageSourceDialog()
        );

        btnUpdateEntry.setOnClickListener(
                v -> updateEntry()
        );
    }

    private void initializeViews() {

        etEditFullName =
                findViewById(
                        R.id.etEditFullName
                );

        etEditNickname =
                findViewById(
                        R.id.etEditNickname
                );

        etEditBirthday =
                findViewById(
                        R.id.etEditBirthday
                );

        etEditFavoriteColor =
                findViewById(
                        R.id.etEditFavoriteColor
                );

        etEditFavoriteFood =
                findViewById(
                        R.id.etEditFavoriteFood
                );

        etEditHobby =
                findViewById(
                        R.id.etEditHobby
                );

        etEditDream =
                findViewById(
                        R.id.etEditDream
                );

        etEditFavoriteQuote =
                findViewById(
                        R.id.etEditFavoriteQuote
                );

        ivEditImage =
                findViewById(
                        R.id.ivEditImage
                );

        btnReplaceImage =
                findViewById(
                        R.id.btnReplaceImage
                );

        btnUpdateEntry =
                findViewById(
                        R.id.btnUpdateEntry
                );
    }

    private void loadEntry() {

        currentEntry =
                databaseHelper.getEntry(
                        entryId
                );

        if (currentEntry == null) {

            showErrorAndFinish(
                    "This slambook entry no longer exists."
            );

            return;
        }

        etEditFullName.setText(
                currentEntry.getFullName()
        );

        etEditNickname.setText(
                currentEntry.getNickname()
        );

        etEditBirthday.setText(
                currentEntry.getBirthday()
        );

        etEditFavoriteColor.setText(
                currentEntry.getFavoriteColor()
        );

        etEditFavoriteFood.setText(
                currentEntry.getFavoriteFood()
        );

        etEditHobby.setText(
                currentEntry.getHobby()
        );

        etEditDream.setText(
                currentEntry.getDream()
        );

        etEditFavoriteQuote.setText(
                currentEntry.getFavoriteQuote()
        );

        originalImagePath =
                currentEntry.getImagePath();

        selectedImagePath =
                originalImagePath;

        displayImage(
                selectedImagePath
        );
    }

    private void showImageSourceDialog() {

        String[] choices = {
                "Camera",
                "Gallery"
        };

        new AlertDialog.Builder(this)

                .setTitle("Replace Profile Picture")

                .setItems(
                        choices,
                        (dialog, which) -> {

                            if (which == 0) {

                                checkCameraPermission();

                            } else {

                                openGallery();
                            }
                        }
                )

                .setNegativeButton(
                        "Cancel",
                        null
                )

                .show();
    }

    private void checkCameraPermission() {

        if (
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
        ) {

            openCamera();

        } else {

            cameraPermissionLauncher.launch(
                    Manifest.permission.CAMERA
            );
        }
    }

    private void openCamera() {

        try {

            cameraFile =
                    ImageUtils.createImageFile(
                            this
                    );

            cameraUri =
                    FileProvider.getUriForFile(
                            this,
                            getPackageName()
                                    + ".fileprovider",
                            cameraFile
                    );

            cameraLauncher.launch(
                    cameraUri
            );

        } catch (Exception e) {

            showDialog(
                    "Camera Error",
                    "The camera could not be opened."
            );
        }
    }

    private void openGallery() {

        galleryLauncher.launch(
                "image/*"
        );
    }

    private void replaceImage(
            String newImagePath
    ) {

        if (
                newImagePath == null ||
                        newImagePath.isEmpty()
        ) {
            return;
        }

        // Delete a previously selected replacement image.
        // Do NOT delete the original image here.
        if (
                !selectedImagePath.isEmpty() &&
                        !selectedImagePath.equals(
                                originalImagePath
                        )
        ) {

            ImageUtils.deleteImage(
                    selectedImagePath
            );
        }

        selectedImagePath =
                newImagePath;

        displayImage(
                selectedImagePath
        );
    }

    private void displayImage(
            String imagePath
    ) {

        if (
                imagePath != null &&
                        !imagePath.isEmpty()
        ) {

            android.graphics.Bitmap bitmap =
                    ImageUtils.loadImage(
                            imagePath
                    );

            if (bitmap != null) {

                ivEditImage.setImageBitmap(
                        bitmap
                );

                return;
            }
        }

        ivEditImage.setImageResource(
                android.R.drawable.ic_menu_camera
        );
    }

    private boolean validateInput() {

        boolean valid = true;

        String fullName =
                etEditFullName
                        .getText()
                        .toString()
                        .trim();

        String nickname =
                etEditNickname
                        .getText()
                        .toString()
                        .trim();

        String birthday =
                etEditBirthday
                        .getText()
                        .toString()
                        .trim();

        if (fullName.isEmpty()) {

            etEditFullName.setError(
                    "Full name is required"
            );

            etEditFullName.requestFocus();

            valid = false;
        }

        if (nickname.isEmpty()) {

            etEditNickname.setError(
                    "Nickname is required"
            );

            if (valid) {
                etEditNickname.requestFocus();
            }

            valid = false;
        }

        if (birthday.isEmpty()) {

            etEditBirthday.setError(
                    "Birthday is required"
            );

            if (valid) {
                etEditBirthday.requestFocus();
            }

            valid = false;
        }

        return valid;
    }

    private void updateEntry() {

        if (!validateInput()) {

            showDialog(
                    "Incomplete Slambook",
                    "Please fill in all required fields."
            );

            return;
        }

        String fullName =
                etEditFullName
                        .getText()
                        .toString()
                        .trim();

        String nickname =
                etEditNickname
                        .getText()
                        .toString()
                        .trim();

        String birthday =
                etEditBirthday
                        .getText()
                        .toString()
                        .trim();

        String favoriteColor =
                etEditFavoriteColor
                        .getText()
                        .toString()
                        .trim();

        String favoriteFood =
                etEditFavoriteFood
                        .getText()
                        .toString()
                        .trim();

        String hobby =
                etEditHobby
                        .getText()
                        .toString()
                        .trim();

        String dream =
                etEditDream
                        .getText()
                        .toString()
                        .trim();

        String favoriteQuote =
                etEditFavoriteQuote
                        .getText()
                        .toString()
                        .trim();

        boolean updated =
                databaseHelper.updateEntry(
                        entryId,
                        fullName,
                        nickname,
                        birthday,
                        favoriteColor,
                        favoriteFood,
                        hobby,
                        dream,
                        favoriteQuote,
                        selectedImagePath
                );

        if (updated) {

            // Delete the old profile picture only after
            // the database successfully updates.
            if (
                    !originalImagePath.isEmpty() &&
                            !originalImagePath.equals(
                                    selectedImagePath
                            )
            ) {

                ImageUtils.deleteImage(
                        originalImagePath
                );
            }

            new AlertDialog.Builder(this)

                    .setTitle("Updated!")

                    .setMessage(
                            "The slambook entry was updated successfully."
                    )

                    .setPositiveButton(
                            "OK",
                            (dialog, which) ->
                                    finish()
                    )

                    .show();

        } else {

            showDialog(
                    "Update Failed",
                    "The slambook entry could not be updated."
            );
        }
    }

    private void showDialog(
            String title,
            String message
    ) {

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(
                        "OK",
                        null
                )
                .show();
    }

    private void showErrorAndFinish(
            String message
    ) {

        new AlertDialog.Builder(this)

                .setTitle("Error")

                .setMessage(message)

                .setPositiveButton(
                        "OK",
                        (dialog, which) ->
                                finish()
                )

                .show();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}